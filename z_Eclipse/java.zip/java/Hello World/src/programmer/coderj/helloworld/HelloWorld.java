package programmer.coderj.helloworld;

import com.godtsoft.diyjava.DIYWindow;

public class HelloWorld extends DIYWindow {

	public HelloWorld() {
        // variables
		String word1 = "Mercury";
		String word2 = "Venus";
		String statement = "The first planet is " + word1 + "\nThen comes " + word2;
		
        // outputs
		print("Hello World");
		print(word1);
		print(word2);
		print(statement);
		print("Annette said \"hi\".");
	}

    public static void main(String[] args) {
        new HelloWorld();
    }
}
